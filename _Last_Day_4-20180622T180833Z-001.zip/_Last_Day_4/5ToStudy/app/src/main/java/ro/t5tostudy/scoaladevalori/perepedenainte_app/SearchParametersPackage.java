package ro.t5tostudy.scoaladevalori.perepedenainte_app;

import java.io.Serializable;

public class SearchParametersPackage implements Serializable {
    public String subject;
    public String testteza;
    public String profil;
    public String grade;
    public String chapter;
}
